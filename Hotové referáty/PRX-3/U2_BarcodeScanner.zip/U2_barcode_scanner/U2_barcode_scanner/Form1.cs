﻿/* ---------------------------------------------------------------
		
			 Daniel Dobeš A4
	
		 Program - Barcode scanner
		 Hardware: USB scanner
		 Version: 3.3
         		 
 		 Using
            - 2 timer tick (as a interrupt) - automatic reading
            - 2 button - pay & overview 
            - list - to show purchase
            - 3 textBox (Barcode; Customer; Subtotal)

-----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;        //needed to work with files

namespace U2_barcode_scanner
{
    public partial class Form1 : Form
    {
        //Initialization
        private string Barcode;
        private string Customername;
        private string Read;
        private string Product;
        private string Productname;
        private string Price;
        private string[] receipt_product = new string[100]; //maximal products/purchase = 100
        private string[] all_product = new string[200];     //maximal product in database = 200
        private string[] all_customer = new string[200];    //maximal customer in database = 200;
        private int[] customer_count = new int[200];        //count of visits each customer
        private int[] product_count = new int[200];         //count of sold each products
        private double[] receipt_price = new double[100];
        private double Subtotal;
        private double Total;
        //private int index0 = 0;           //used as a local counter
        private int index1 = 0;             //determines the order of items 
                                            //used in Timer_interrupt_products - null when pay
        //private int index2 = 0;           //used as a local counter
        //private int index3 = 0;           //used as a local variable
        private int productnumber = 0;
        private int customernumber = 0;
        private int purchasenumber = 0;

        public Form1()
        {
            InitializeComponent();
            
            Timer_interrupt_customer.Enabled = true; //Scan customer
            Timer_interrupt_products.Enabled = true; //Scan product
            buttonOverview.Enabled = false;      //allow after at least one purchase

            //fill in "field" with all products from database
            using (StreamReader AllProductsRead = new StreamReader(@"Products.csv"))
            {
                int index0 = 0;     //local variable
                try
                {
                    while (true)    //endless cycle (until all products are read)
                    {
                        index0++;                            //counter for number of product
                        Read = AllProductsRead.ReadLine();   //load 1 line
                        string[] separate = Read.Split(';'); //separate acord ";"
                        all_product[index0] = separate[1];   //save product name
                    }
                }
                catch { }
                productnumber = index0; //set number of product
            }
            //fill in "field" with all customers from database
            using (StreamReader AllCustomersRead = new StreamReader(@"Customer.csv"))
            {
                int index0 = 0;     //local variable
                try
                {
                    while (true)    //endless cycle (until all customers are read)
                    {
                        index0++;                            //counter for number of customer
                        Read = AllCustomersRead.ReadLine();  //load 1 line
                        string[] separate = Read.Split(';'); //separate acord ";"
                        all_customer[index0] = separate[1];  //save customer name
                    }
                }
                catch { }
                customernumber = index0; //set number of product
            }
            //end of initialization
        }

        private void Timer_interrupt_customer_Tick(object sender, EventArgs e)
        {
            try
            {
                int index2 = 0;
                string temp1 = textBox_Barcode.Text;  //read Barcode from textbox
                //compare barcode with database of customer
                using (StreamReader CustomerRead = new StreamReader(@"Customer.csv"))
                {
                    while (temp1 != Barcode) //cycle until the customer is read
                    {
                        index2++;
                        Read = CustomerRead.ReadLine();      //load 1 line
                        string[] separate = Read.Split(';'); //separate acord ";"
                        Barcode = separate[0];               //save barcode for next compare
                        Customername = separate[1];          //save customer name
                    }
                }
                textBox_customer.Text = Customername;        //show customer name
                customer_count[index2]++;                    //count of visits each customer
                textBox_Barcode.Text = "";                   //clear textBox barcode
                Barcode = "";                                //clear variable barcode
                Timer_interrupt_customer.Enabled = false;    //turn off, when customer is set
            }
            catch
            { }
        }

        private void Timer_interrupt_products_Tick(object sender, EventArgs e)
        {
            if (textBox_Barcode.Text != "")           //test if sth is in textBox_Barcode
            {                                         //yes -> do this (no -> skip) 
                try
                {
                    int index2 = 0;
                    string temp1 = textBox_Barcode.Text;  //read Barcode from textbox
                                                          //compare barcode with database of products
                    using (StreamReader ProductsRead = new StreamReader(@"Products.csv"))
                    {
                        while (temp1 != Barcode)
                        {
                            Read = ProductsRead.ReadLine();      //load 1 line
                            string[] separate = Read.Split(';'); //separate acored ";"
                            Barcode = separate[0];               //save bracode for next compare
                            Productname = separate[1];           //save product name
                            Price = separate[2];                 //save product price
                            index2++;
                        }
                    }
                    //used in receipt
                    receipt_product[index1] = Productname;           //store in "field"
                    receipt_price[index1] = Convert.ToDouble(Price); //store in "field"
                    index1++;                //determines the order of items
                    product_count[index2]++; //count of products sold
                    //show product in purchase (in list)
                    listBox_purchase.Items.Add(Product = Productname + "......" + Price + ",- Kč");
                    //summary purchase subtotal & show
                    Subtotal = Subtotal + Convert.ToDouble(Price);
                    textBox_subtotal.Text = Convert.ToString(Subtotal) + " ,- Kč";
                    textBox_Barcode.Text = "";            //clear textbox barcode
                    
                    //enabled when at least one item is selected
                    //buttonPay.Enabled = true;

                }
                catch
                { }
            }   //end of test if sth is in textBox_Barcode
        }       //end of interrupt

        //print receipt
        private void buttonPay_Click(object sender, EventArgs e)
        {
            using (StreamWriter Receipt = new StreamWriter(@"receipt.txt"))
            {
                Receipt.WriteLine();
                Receipt.WriteLine("------------------ Uctenka -------------------");
                Receipt.WriteLine("Zakaznik:            " + textBox_customer.Text);
                Receipt.WriteLine("----------------------------------------------");
                Receipt.WriteLine("Zbozi                Cena");
                for (int index0 = 0; index0 < index1; index0++)
                {
                    //cycle to write out all product in purchase
                    Receipt.WriteLine(receipt_product[index0] + "        " + receipt_price[index0] + " ,- Kč");
                }
                Receipt.WriteLine("----------------------------------------------");
                Receipt.WriteLine("Součet:              " + textBox_subtotal.Text);
                Receipt.WriteLine("Datum vystaveni:     " + DateTime.Now);
                Receipt.WriteLine("----------------------------------------------");
                Receipt.Flush();
            }
            //statistics used for overview
            Total = Total + Subtotal;
            purchasenumber++;
            //prepare for new purchase
            buttonOverview.Enabled = true;      //allow after at least one purchase
            index1 = 0;     //determines the order of items used
            Subtotal = 0;
            textBox_subtotal.Text = "";
            textBox_customer.Text = "";
            Timer_interrupt_customer.Enabled = true;
            listBox_purchase.Items.Clear();
            //clear "fieald"
            for (int index0 = 0; index0 < receipt_product.Length; index0++)
            {
                receipt_product[index0] = "";
                receipt_price[index0] = 0;
            }
        }

        private void buttonOverview_Click(object sender, EventArgs e)
        {
            using (StreamWriter Overview = new StreamWriter(@"overview.txt"))
            {
                Overview.WriteLine();
                Overview.WriteLine("------------------ Přehled -------------------");
                Overview.WriteLine("Tržba:                      " + Total + ",- Kč");
                Overview.WriteLine("Průměrný výdělek za nákup:  " + Total / purchasenumber + ",- Kč");
                Overview.WriteLine("----------------------------------------------");
                Overview.WriteLine("Zbozi              Počet prodaných kusů");
                //cycle to write out all product                
                for (int index0 = 1; index0 != productnumber; index0++)
                {
                    Overview.WriteLine(all_product[index0] + "             " + product_count[index0] + "x");
                }
                Overview.WriteLine("----------------------------------------------");
                int index3;         //local variable
                //find the most sold product
                index3 = 0 + product_count.Max();
                index3 = Array.IndexOf(product_count, index3);
                Overview.WriteLine("Nejvíce kupovaný produkt:    " + all_product[index3]);
                //find the least sold product
                index3 = 0 + product_count.Min();
                index3 = Array.IndexOf(product_count, index3);
                Overview.WriteLine("Nejméně kupovaný produkt:    " + all_product[index3]);
                Overview.WriteLine("----------------------------------------------");
                //write out count of purchase for each customer
                Overview.WriteLine("Zákazník             Počet nákupů");
                for (int index0 = 1; index0 != customernumber; index0++)
                {
                    Overview.WriteLine(all_customer[index0] + "           " + customer_count[index0] + "x");
                }
                Overview.WriteLine("----------------------------------------------");
                //find out the customer with the highest count of visits
                index3 = 0 + customer_count.Max();
                index3 = Array.IndexOf(customer_count, index3);
                Overview.WriteLine("Nejčastější zákazník:        " + all_customer[index3]);
                Overview.WriteLine("----------------------------------------------");
            }
        }
    }
}
