﻿namespace U2_barcode_scanner
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.buttonOverview = new System.Windows.Forms.Button();
            this.buttonPay = new System.Windows.Forms.Button();
            this.textBox_subtotal = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.listBox_purchase = new System.Windows.Forms.ListBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_Barcode = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Timer_interrupt_customer = new System.Windows.Forms.Timer(this.components);
            this.Timer_interrupt_products = new System.Windows.Forms.Timer(this.components);
            this.textBox_customer = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // buttonOverview
            // 
            this.buttonOverview.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonOverview.Location = new System.Drawing.Point(508, 272);
            this.buttonOverview.Name = "buttonOverview";
            this.buttonOverview.Size = new System.Drawing.Size(109, 92);
            this.buttonOverview.TabIndex = 23;
            this.buttonOverview.Text = "Overview";
            this.buttonOverview.UseVisualStyleBackColor = true;
            this.buttonOverview.Click += new System.EventHandler(this.buttonOverview_Click);
            // 
            // buttonPay
            // 
            this.buttonPay.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.buttonPay.Location = new System.Drawing.Point(508, 168);
            this.buttonPay.Name = "buttonPay";
            this.buttonPay.Size = new System.Drawing.Size(109, 92);
            this.buttonPay.TabIndex = 22;
            this.buttonPay.Text = "Pay";
            this.buttonPay.UseVisualStyleBackColor = true;
            this.buttonPay.Click += new System.EventHandler(this.buttonPay_Click);
            // 
            // textBox_subtotal
            // 
            this.textBox_subtotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_subtotal.Enabled = false;
            this.textBox_subtotal.Location = new System.Drawing.Point(508, 129);
            this.textBox_subtotal.Name = "textBox_subtotal";
            this.textBox_subtotal.Size = new System.Drawing.Size(109, 22);
            this.textBox_subtotal.TabIndex = 17;
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label4.Location = new System.Drawing.Point(183, 131);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 23);
            this.label4.TabIndex = 21;
            this.label4.Text = "Purchase:";
            // 
            // listBox_purchase
            // 
            this.listBox_purchase.FormattingEnabled = true;
            this.listBox_purchase.ItemHeight = 16;
            this.listBox_purchase.Location = new System.Drawing.Point(186, 168);
            this.listBox_purchase.Name = "listBox_purchase";
            this.listBox_purchase.Size = new System.Drawing.Size(306, 196);
            this.listBox_purchase.TabIndex = 20;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(433, 131);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(112, 23);
            this.label3.TabIndex = 19;
            this.label3.Text = "Subtotal:";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(433, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 23);
            this.label2.TabIndex = 16;
            this.label2.Text = "Customer:";
            // 
            // textBox_Barcode
            // 
            this.textBox_Barcode.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_Barcode.Location = new System.Drawing.Point(261, 86);
            this.textBox_Barcode.Name = "textBox_Barcode";
            this.textBox_Barcode.Size = new System.Drawing.Size(109, 22);
            this.textBox_Barcode.TabIndex = 15;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(183, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(112, 23);
            this.label1.TabIndex = 14;
            this.label1.Text = "Barcode:";
            // 
            // Timer_interrupt_customer
            // 
            this.Timer_interrupt_customer.Enabled = true;
            this.Timer_interrupt_customer.Tick += new System.EventHandler(this.Timer_interrupt_customer_Tick);
            // 
            // Timer_interrupt_products
            // 
            this.Timer_interrupt_products.Enabled = true;
            this.Timer_interrupt_products.Tick += new System.EventHandler(this.Timer_interrupt_products_Tick);
            // 
            // textBox_customer
            // 
            this.textBox_customer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox_customer.Enabled = false;
            this.textBox_customer.Location = new System.Drawing.Point(508, 86);
            this.textBox_customer.Name = "textBox_customer";
            this.textBox_customer.Size = new System.Drawing.Size(109, 22);
            this.textBox_customer.TabIndex = 24;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.textBox_customer);
            this.Controls.Add(this.buttonOverview);
            this.Controls.Add(this.buttonPay);
            this.Controls.Add(this.textBox_subtotal);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.listBox_purchase);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_Barcode);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonOverview;
        private System.Windows.Forms.Button buttonPay;
        private System.Windows.Forms.TextBox textBox_subtotal;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ListBox listBox_purchase;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox_Barcode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer Timer_interrupt_customer;
        private System.Windows.Forms.Timer Timer_interrupt_products;
        private System.Windows.Forms.TextBox textBox_customer;
    }
}

