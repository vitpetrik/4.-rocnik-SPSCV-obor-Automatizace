/* ---------------------------------------------------------------
		
			 Daniel Dobeš A4
	
		 Program - Výtah
		 Hardware: Výtah
		 Version: 1.2

		 Connection
		 	OUT
			- Port 1 - Port A
				bit 7 - direction (0 down; 1 up)
				bit 3 - motor (0 on; 1 off)
			- Port 2 - Port B
				bit 7 - LED up
				bit 6 - LED down
				bit 5 - tone notice
				bit 4 - light in cabin
				bit 2 - floor number - BCD code - C
				bit 1 - floor number - BCD code - B
				bit 0 - floor number - BCD code - A
			IN
			- Port 3 - Port A
				bit 7 - Button in cabin - 4
				bit 6 - Button in cabin - 3
				bit 5 - Button in cabin - 2
				bit 4 - Button in cabin - 1
				bit 3 - Button in floor - 4
				bit 2 - Button in floor - 3
				bit 1 - Button in floor - 2
				bit 0 - Button in floor - 1
			- Port 4 - Port B
				bit 7 - sensor on floor - 4
				bit 6 - sensor on floor - 3
				bit 5 - sensor on floor - 2
				bit 4 - sensor on floor - 1
				bit 3 - door sensor
				bit 2 - cabin pressure plate
 		 Comment
			- int main(void) contains sequence of each
				individual program units
				
-----------------------------------------------------------------*/	
	
	//Initialization
	#include<stdio.h>
	#include<conio.h>	
	#include<dos.h>
	#include<time.h>
	
	#define portA 0x300 //P1, P3
	#define portB 0x301 //P2, P4
	#define first_half 0xF0
	#define second_half 0x0F
	#define mask_door 0x1111_0111
	#define mask_cabin 0x1111_1011
	#define mask_tone1 0x1101_1111
	#define mask_tone2 0x0010_0000
	#define mask_led_up 0x0111_1111
	#define mask_led_down 0x1011_1111
	#define mask_led_both 0x0011_1111
	#define mask_light1 0x1110_1111
	#define mask_light2 0x0001_0000
	#define time 500 //delay 0,5s
		
	int port1, port2 = 0xFF;	//default value
	int port3, port4;
	int temp;
	int index = 0;	//using in switch
	int actual_floor, destination_floor;
		
	int main(void)
	{
		while(1)
		{	//sequence
			out();			//outport
			in();			//load
			close_door();	//waiting for close door
			current_floor();//detecting actual floor
			target_floor();	//destination floor detection
			direction();	//determines rotation direction
			motor();		//turns the motor on and off
		} //end of while
	}	//end of main
	
	int in()
	{
		port3 = inportb(portA);
		port4 = inportb(portB);
	}
	
	int out()
	{
		outportb(portA, port1);
		outportb(portB, port2);
	}	
	
	int direction()
	{
		if(actual_floor == destination_floor)
		{
			switch(index)
			{
				case 0:
				{
					tone();
					port2 = port2 & mask_led_both;
					index = 1;
				}
					break;
				case 1:
				{}
					break;	
			} //end of switch
		}
		else
		{
			if(actual_floor > destination_floor)
			{	//set 0; bits 7-4; port1
				port1 = port1 & second_half;
				port2 = port2 & mask_led_down;
			}
			if(actual_floor < destination_floor) 
			{	//set 1; bits 7-4; port1
				port1 = port1 | first_half;
				port2 = port2 & mask_led_up;
			}
			index = 0;	//reset switch
		}
	}	//end of direction
	
	int motor()
	{
		if(actual_floor == destination_floor)
		{	//set 1; bits 3-0; port1
			port1 = port1 | second_half;
		}
		else
		{	//set 0; bits 3-0; port1
			port1 = port1 & first_half;
		}
	}	//end of motor

	int current_floor()
	{	//mask port4 -> compare to recognize actual_floor
		temp = port4 | second_half;
		if(temp == 0x7F) actual_floor = 4;
		if(temp == 0xBF) actual_floor = 3;
		if(temp == 0xDF) actual_floor = 2;
		if(temp == 0xEF) actual_floor = 1;
		//240 - default mask for BCD display
		temp = 240 + actual_floor;
		port2 = port2 & temp;
	}	//end of current_floor
	
	int close_door()
	{
		do
		{	//cycle till the closed door
			in();
			temp = port4 | mask_door;
			printf("\nDvere otevreny!");
			delay(time);
		} while (temp != 0xF7)
			clrscr();
	}	//end of close_door

	int target_floor()
	{
		temp = port4 | mask_cabin;
		if(temp == 0xFB) temp = port3 | second_half;
		{	//inside the cabin
			button();
			port2 = port2 & mask_light1;	//light on
		}
		if(temp == 0xFF) temp = port3 | first_half;
		{	//outside the cabin
			button();
			port2 = port2 & mask_light2;	//light off
		}
	}	//end of target_floor

	int tone() //0,5s tone
	{
		port2 = port2 & mask_tone1;
		out();
		delay(time);
		port2 = port2 | mask_tone2;
		out();
	}	//end of tone

	int button()
	{
		if((temp == 0x7F)||(temp == 0xF7)) destination_floor = 4;
		if((temp == 0xBF)||(temp == 0xFB)) destination_floor = 3;
		if((temp == 0xDF)||(temp == 0xFD)) destination_floor = 2;
		if((temp == 0xEF)||(temp == 0xFE)) destination_floor = 1;
	}	//end of button
