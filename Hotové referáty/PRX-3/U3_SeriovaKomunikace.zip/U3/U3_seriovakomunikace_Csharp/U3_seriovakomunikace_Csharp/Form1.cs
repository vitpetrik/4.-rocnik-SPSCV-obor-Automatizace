﻿/* ---------------------------------------------------------------
		
			 Daniel Dobeš A4
	
		 Program - Serial Communication
		 Version: 1			 

 		 Comment
			- Not working
			- Not set baudRate
			- Not set COM
            - Not

-----------------------------------------------------------------*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Windows.Forms;

namespace U3_seriovakomunikace_Csharp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            static bool _continue;
            static SerialPort _serialPort;
            textBox_SerialPort.Text = "";
            _serialPort = new SerialPort(); //create a new SerialPort
            _serialPort.DataBits = SetPortDataBits(_serialPort.DataBits);
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            //try all allowed SerialPort
            foreach (string s in System.IO.Ports.SerialPort.GetPortNames())
            {
                //read all data bits   
                string dataBits = dataBits + defaultPortDataBits.ToString();
                textBox_SerialPort.Text = dataBits;
            }
        }
    }
}
