﻿/* ---------------------------------------------------------------
		
			 Daniel Dobeš A4
	
		 Program - Tenis
		 Version: 2.1

 		 Comment
			- using 4 timer (ball control, pad control,
              preparation for next round, pause)
            - possibility to pause the game with
              the space bar or the "P"
            - any number of rounds
            - any speed of the pads
            - possibility to play against a computer
              using "C" to switch

-----------------------------------------------------------------*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D; //Must be defined
using System.Reflection;        //Must be defined

namespace U6_Tenis
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            timer_preparation.Enabled = true;   
            timer_ball.Enabled = false;
            timer_pad.Enabled = true;
            timer_pause.Enabled = true;
            label_pause.Visible = false;
        }
        
        int pad1length = 125;                   //left pad length
        int pad2length = 125;                   //left pad length
        int xball = 430, yball = 280;           //xy ball coordinates
        int pad1 = 238, pad2 = 238;             //y pad coordinates 
        int pad1up, pad1down, pad2up, pad2down; //key control
        int ballspeed = 0;                      //default ball speed
        int xballdirection = 1, yballdirection = 1;     //default ball direction
        int RightPlayerScore = 0, LeftPlayerScore = 0;  //score each player
        int difficulty = 3;         //default
        int Round = 0;              //actual round
        int RoundCount = 5;         //number of round to win
        int padspeed = 15;          //10 - 20             
        int pause = 0;              //if 1 -> game is paused
        int computer = 0;           //if 1 -> player 2 = computer
        Random ball = new Random(); //random ball direct

        private void Form1_Load(object sender, EventArgs e)
        {
            //Double buffer used when panel is refreshed -> no flashing
            typeof(Panel).InvokeMember("DoubleBuffered", BindingFlags.SetProperty 
            | BindingFlags.Instance | BindingFlags.NonPublic,
            null, panel_playground, new object[] { true });
        }

        private void panel_playground_Paint(object sender, PaintEventArgs e)
        {
            Graphics tenis = e.Graphics;                                
            Pen BlackPen = new Pen(Color.Black, 3);                 //definitions of brushes and pen
            SolidBrush RedBrush = new SolidBrush(Color.DarkRed);        
            SolidBrush GreenBrush = new SolidBrush(Color.LightGreen);
            SolidBrush YellowBrush = new SolidBrush(Color.Yellow);
            SolidBrush BlueBrush = new SolidBrush(Color.DarkSlateBlue);
            tenis.FillRectangle(GreenBrush, 0, 0, 900, 600);            //background of playground
            tenis.DrawLine(BlackPen, 450, 0, 450, 600);                 //middle line
            tenis.DrawRectangle(BlackPen, 0, 0, 900, 600);              //border line
            tenis.FillEllipse(YellowBrush, xball, yball, 40, 40);       //ball
            tenis.DrawEllipse(BlackPen, xball, yball, 40, 40);          //ball
            tenis.FillRectangle(RedBrush, 10, pad1, 25, pad1length);     //pad - player 1 - left
            tenis.FillRectangle(BlueBrush, 865, pad2, 25, pad2length);   //pad - player 2 - right
        }
        //pad control
        protected override void OnKeyDown(KeyEventArgs e)   //Keystroke test
        {
            //if "key" is pressed -> set pad divergence 
            if ((e.KeyCode == Keys.Space) || (e.KeyCode == Keys.P)) pause++;
            if (e.KeyCode == Keys.C)
            {
                computer++;
                label_player2.Text = Convert.ToString("Computer");
                pad2length = 600;   //set full wall pad
                pad2 = 0;
            }
            if (e.KeyCode == Keys.W) pad1up = 1;
            if (e.KeyCode == Keys.S) pad1down = 1;
            if (e.KeyCode == Keys.Up) pad2up = 1;
            if (e.KeyCode == Keys.Down) pad2down = 1;
        }
        protected override void OnKeyUp(KeyEventArgs e)   //Key Release Test
        {
            if (((e.KeyCode == Keys.Space) || (e.KeyCode == Keys.P)) && (pause == 2))
            {
                pause = 0;
                timer_ball.Enabled = true;
                timer_pad.Enabled = true;
                label_pause.Visible = false;
            }
            if ((e.KeyCode == Keys.C) && (computer == 2))
            {
                computer = 0;
                label_player2.Text = Convert.ToString("Player 2");
                pad2length = 125;      //reset pad 2
                pad2 = 238;
            }
            //if "key" is unpressed -> reset pad divergence 
            if (e.KeyCode == Keys.W) pad1up = 0;
            if (e.KeyCode == Keys.S) pad1down = 0;
            if (e.KeyCode == Keys.Up) pad2up = 0;
            if (e.KeyCode == Keys.Down) pad2down = 0;
        }

        private void timer_pad_Tick(object sender, EventArgs e)
        {
            //if some key was pressed -> set new y pad coordinates & refresh panel
            if (pad1up == 1 && pad1 > 0) pad1 = pad1 - padspeed;    
            if (pad1down == 1 && pad1 < 475) pad1 = pad1 + padspeed;
            if (computer != 1)
            {
                if (pad2up == 1 && pad2 > 0) pad2 = pad2 - padspeed;
                if (pad2down == 1 && pad2 < 475) pad2 = pad2 + padspeed;
            }
             Refresh();
        }       //end of timer_pad_Tick

        private void timer_ball_Tick(object sender, EventArgs e)
        {
            ballspeed = difficulty;
            xball = xball + (xballdirection * ballspeed);      //ball x movement
            yball = yball + (yballdirection * ballspeed);      //ball y movement

            //bounce from the wall
            if ((yball <= 0) || (yball >= 560)) yballdirection = -yballdirection;
            
            //bounce from the pad
            if (((xball <= 35) && (yball > pad1) && (yball < pad1 + pad1length)) 
             || (xball >= 830) && (yball > pad2) && (yball < pad2 + pad2length))
                xballdirection = -xballdirection;

            if ((xball < 1) || (xball > 850))
            {
                if (xball < 1) RightPlayerScore++;  //left wall hit
                if (xball > 850) LeftPlayerScore++; //right wall hit

                ballspeed = 0;                      //stop ball
                xball = 430;                        //xy ball coordinates
                yball = 280;
                timer_ball.Enabled = false;         //turn off timer - ball control
                timer_preparation.Enabled = true;   //turn on timer - preparation
            }

            if ((LeftPlayerScore == RoundCount) || (RightPlayerScore == RoundCount))
            {
                timer_preparation.Enabled = false;
                if (computer == 1)
                {
                    MessageBox.Show("You lose, try again", "", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                else
                {
                    if (LeftPlayerScore == RoundCount)              //Left player win
                        MessageBox.Show("Left player win", "Congratulations!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    if (RightPlayerScore == RoundCount)             //Right player win
                        MessageBox.Show("Right player win", "Congratulations!", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                }
                LeftPlayerScore = 0;     //Score reset
                RightPlayerScore = 0;
                difficulty = 3;          //difficulty reset
                Round = 0;               //round reset
                timer_preparation.Enabled = true;
            }
            Refresh();
        }           //end of timer_ball_Tick

        private void timer_preparation_Tick(object sender, EventArgs e)
        {   //delay 2 sec - preparation for next round
            difficulty++;   //increase ball speed -> higher difficulty
            Round++;        //increment round

            //show statistic
            label_LeftPlayerScore.Text = Convert.ToString(LeftPlayerScore);
            label_RightPlayerScore.Text = Convert.ToString(RightPlayerScore);
            label_round.Text = Convert.ToString(Round);

            //generation random number -> random ball direction
            if (ball.Next(0, 1) == 1) xballdirection = -xballdirection;
            if (ball.Next(0, 1) == 1) yballdirection = -yballdirection;
            
            timer_ball.Enabled = true;             //turn on timer - ball control
            timer_preparation.Enabled = false;     //turn off timer - preparation
        }           //end of timer_preparation_Tick

        private void timer_pause_Tick(object sender, EventArgs e)
        {
            if (pause == 1)
            {
                timer_ball.Enabled = false;
                timer_pad.Enabled = false;
                timer_preparation.Enabled = false;
                label_pause.Visible = true;
            }
        }           //end of timer_pause_Tick
    }
}
