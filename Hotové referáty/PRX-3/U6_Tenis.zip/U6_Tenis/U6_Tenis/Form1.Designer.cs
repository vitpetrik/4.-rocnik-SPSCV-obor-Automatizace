﻿namespace U6_Tenis
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel_playground = new System.Windows.Forms.Panel();
            this.timer_pad = new System.Windows.Forms.Timer(this.components);
            this.timer_ball = new System.Windows.Forms.Timer(this.components);
            this.label_player1 = new System.Windows.Forms.Label();
            this.label_player2 = new System.Windows.Forms.Label();
            this.label_LeftPlayerScore = new System.Windows.Forms.Label();
            this.label_RightPlayerScore = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label_round = new System.Windows.Forms.Label();
            this.timer_preparation = new System.Windows.Forms.Timer(this.components);
            this.timer_pause = new System.Windows.Forms.Timer(this.components);
            this.label_pause = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // panel_playground
            // 
            this.panel_playground.Location = new System.Drawing.Point(12, 176);
            this.panel_playground.Name = "panel_playground";
            this.panel_playground.Size = new System.Drawing.Size(1283, 1019);
            this.panel_playground.TabIndex = 0;
            this.panel_playground.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_playground_Paint);
            // 
            // timer_pad
            // 
            this.timer_pad.Enabled = true;
            this.timer_pad.Interval = 50;
            this.timer_pad.Tick += new System.EventHandler(this.timer_pad_Tick);
            // 
            // timer_ball
            // 
            this.timer_ball.Enabled = true;
            this.timer_ball.Interval = 8;
            this.timer_ball.Tick += new System.EventHandler(this.timer_ball_Tick);
            // 
            // label_player1
            // 
            this.label_player1.BackColor = System.Drawing.Color.Transparent;
            this.label_player1.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_player1.ForeColor = System.Drawing.Color.DarkRed;
            this.label_player1.Location = new System.Drawing.Point(67, 26);
            this.label_player1.Name = "label_player1";
            this.label_player1.Size = new System.Drawing.Size(183, 55);
            this.label_player1.TabIndex = 5;
            this.label_player1.Text = "Player 1";
            this.label_player1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_player2
            // 
            this.label_player2.BackColor = System.Drawing.Color.Transparent;
            this.label_player2.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_player2.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.label_player2.Location = new System.Drawing.Point(379, 26);
            this.label_player2.Name = "label_player2";
            this.label_player2.Size = new System.Drawing.Size(183, 55);
            this.label_player2.TabIndex = 6;
            this.label_player2.Text = "Player 2";
            this.label_player2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_LeftPlayerScore
            // 
            this.label_LeftPlayerScore.BackColor = System.Drawing.Color.Transparent;
            this.label_LeftPlayerScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_LeftPlayerScore.ForeColor = System.Drawing.Color.DarkRed;
            this.label_LeftPlayerScore.Location = new System.Drawing.Point(67, 94);
            this.label_LeftPlayerScore.Name = "label_LeftPlayerScore";
            this.label_LeftPlayerScore.Size = new System.Drawing.Size(183, 55);
            this.label_LeftPlayerScore.TabIndex = 7;
            this.label_LeftPlayerScore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_RightPlayerScore
            // 
            this.label_RightPlayerScore.BackColor = System.Drawing.Color.Transparent;
            this.label_RightPlayerScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_RightPlayerScore.ForeColor = System.Drawing.Color.DarkSlateBlue;
            this.label_RightPlayerScore.Location = new System.Drawing.Point(376, 94);
            this.label_RightPlayerScore.Name = "label_RightPlayerScore";
            this.label_RightPlayerScore.Size = new System.Drawing.Size(183, 55);
            this.label_RightPlayerScore.TabIndex = 8;
            this.label_RightPlayerScore.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 19.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label3.Location = new System.Drawing.Point(688, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(183, 55);
            this.label3.TabIndex = 9;
            this.label3.Text = "Round";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label_round
            // 
            this.label_round.BackColor = System.Drawing.Color.Transparent;
            this.label_round.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_round.Location = new System.Drawing.Point(688, 94);
            this.label_round.Name = "label_round";
            this.label_round.Size = new System.Drawing.Size(183, 55);
            this.label_round.TabIndex = 10;
            this.label_round.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // timer_preparation
            // 
            this.timer_preparation.Interval = 2000;
            this.timer_preparation.Tick += new System.EventHandler(this.timer_preparation_Tick);
            // 
            // timer_pause
            // 
            this.timer_pause.Interval = 10;
            this.timer_pause.Tick += new System.EventHandler(this.timer_pause_Tick);
            // 
            // label_pause
            // 
            this.label_pause.BackColor = System.Drawing.Color.Transparent;
            this.label_pause.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_pause.Location = new System.Drawing.Point(937, 26);
            this.label_pause.Name = "label_pause";
            this.label_pause.Size = new System.Drawing.Size(287, 123);
            this.label_pause.TabIndex = 11;
            this.label_pause.Text = "Pause";
            this.label_pause.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1283, 1019);
            this.Controls.Add(this.label_pause);
            this.Controls.Add(this.label_round);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label_RightPlayerScore);
            this.Controls.Add(this.label_LeftPlayerScore);
            this.Controls.Add(this.label_player2);
            this.Controls.Add(this.label_player1);
            this.Controls.Add(this.panel_playground);
            this.Name = "Form1";
            this.Text = "Tenis";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_playground;
        private System.Windows.Forms.Timer timer_pad;
        private System.Windows.Forms.Timer timer_ball;
        private System.Windows.Forms.Label label_player1;
        private System.Windows.Forms.Label label_player2;
        private System.Windows.Forms.Label label_LeftPlayerScore;
        private System.Windows.Forms.Label label_RightPlayerScore;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label_round;
        private System.Windows.Forms.Timer timer_preparation;
        private System.Windows.Forms.Timer timer_pause;
        private System.Windows.Forms.Label label_pause;
    }
}

