﻿/*
                Úloha: Křižovatka
       Autor: Daniel Dobeš
       Last Update: 16. 10. 2018
       HW: Model křižovatky, Velleman P8055-1 (2x)

       Card 0 (VellemnaP8055-1)
       "PortA"
       Pin OUT
       0; 1; 2; Semafor - hlavní silnice - vlevo
       3; 4; 5; Semafor - hlavní silnice - rovně a vpravo
       Pin IN
       1 Tlačítko 1 - denní režim - ModeDay
       2 Tlačítko 2 - noční režim - ModeNight
       
       Card 1 (VellemnaP8055-1)
       "PortB"
       Pin OUT
       0; 1; 2; 3; Semafor - vedlejší silnice
       4; 5; Semafor - chodci hlavní silnice
       6; 7; Semafor - chodci vedlejší silnice
       
       Princip činnosti:
       - Křižovatka automaticky nastavena na denní režim (možná změna režimu)
       - Při tiknutí Timeru1 je vyvoláno "přerušení":
            -   rozhodnutí o modu (den/noc)
            -   vykreslení 1 stavu
            -   inkrementace stavu
       - při tiknutí Timeru2 je vyvoláno "přerušení":
            -   kontrola HW tlačítek
            -   nastavení Modu v případě aktivního právě jednoho z nich
            -   nulování stavu v druhém modu
       
       Poznámky:
       - Grafika - plně funkční + ovládání v C#
       - Při změně modu (day/night) úmyslný začátek vždy od prvního stavu
       - Použité 2 Timery 
            - 1 vykreslování aktuálního stavu křižovatky
            - 2 kontrola talčítek
       - komentáře nezmenšené pro tisk

*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices; //Knihovna pro přidání hardwaru

namespace Uloha4_Krizovatka
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Timer1.Enabled = true;
        }
        public class K8055D
        {
               //Načtení knihoven a jejích funkcí             
               [DllImport("K8055D.dll")]
               public static extern int OpenDevice(int CardAddress);
               [DllImport("K8055D.dll")]
               public static extern int ReadDigitalChannel(int Channel);
               [DllImport("K8055D.dll")]
               public static extern int WriteAllDigital(int Data);
               [DllImport("K8055D.dll")]
               public static extern int CloseDevice(int CardAddress);
               [DllImport("K8055D.dll")]
               public static extern int SetCurrentDevice(int CardAddress);
        }

        //definice proměných
        private int d = 20;                                  //průměr světla semaforu

        //definice malířské výbavy
        private Pen black = new Pen(Color.Black, 2);
        private SolidBrush Red = new SolidBrush(Color.Red);
        private SolidBrush Orange = new SolidBrush(Color.Orange);
        private SolidBrush Green = new SolidBrush(Color.Green);
        private SolidBrush White = new SolidBrush(Color.White);
        private SolidBrush Gray = new SolidBrush(Color.Gray);
        private SolidBrush LightGreen = new SolidBrush(Color.LightGreen);
        private SolidBrush LightGray = new SolidBrush(Color.LightGray);

        //definice proměných pro větvení
        private int ModeDay = 0;                             //přednastavení výchozího reřimu
        private int ModeNight = 1;                             
        private int StatusDay, StatusNight;                  //určování stavu rozsvícených světel

        //definice stavů - bitových kombinacích posílaných do HW
        //Denní stavy - private int Status<number><port> = 0b0000_0000;
        private int Status1A, Status7A, Status8A = 0b1000_1000;
        private int Status9A, Status10A, Status11A = 0b1000_1000;
        private int Status1B, Status7B = 0b1000_1010;
        private int Status2A = 0b1000_1100;
        private int Status2B, Status3B, Status4B = 0b1000_0110;
        private int Status5B, Status6B = 0b1000_0110;
        private int Status3A = 0b1000_0010;
        private int Status4A = 0b1100_0010;
        private int Status5A = 0b0010_0010;
        private int Status6A = 0b0100_0100;
        private int Status8B = 0b1010_1001;
        private int Status9B = 0b1110_1001;
        private int Status10B = 0b0011_1001;
        private int Status11B = 0b0100_1001;
        //Noční stavy - private int StatusNight<number><port> = 0b0000_0000;
        private int StatusNight0A, StatusNight0B = 0b0000_0000;
        private int StatusNight1A = 0b0100_0100;
        private int StatusNight1B = 0b0100_0000;
        private int PortA, PortB;                            //Obsah portů posílán do HW

        //definice proměnné určení den/noc
        private int Mode;

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = panel1.CreateGraphics();            //Zapnutí grafiky v panel1
            //Nakreslení křižovatky
            //g.DrawLine(typ čáry, počátční x, počáteční y, šířka, výška);
            g.DrawRectangle(black, 10, 10, 600, 600);        //obvod křižovatky
            g.DrawRectangle(black, 10, 10, 200, 200);        //levá horní výseč
            g.DrawRectangle(black, 10, 410, 200, 200);       //levá dolní výseč
            g.DrawRectangle(black, 410, 10, 200, 200);       //pravá horní výseč
            g.DrawRectangle(black, 410, 410, 200, 200);      //pravá dolní výseč
            g.FillRectangle(Gray, 10, 10, 600, 600);         //obsah křižovatky
            g.FillRectangle(LightGreen, 10, 10, 200, 200);   //levá horní výseč
            g.FillRectangle(LightGreen, 10, 410, 200, 200);  //levá dolní výseč
            g.FillRectangle(LightGreen, 410, 10, 200, 200);  //pravá horní výseč
            g.FillRectangle(LightGreen, 410, 410, 200, 200); //pravá dolní výseč
            g.FillRectangle(LightGray, 210, 50, 200, 80);    //přechod nahoře
            g.FillRectangle(LightGray, 50, 210, 80, 200);    //přechod vlevo
            g.FillRectangle(LightGray, 490, 210, 80, 200);   //přechod vpravo
            g.FillRectangle(LightGray, 210, 490, 200, 80);   //přechod dole

            //Vykreslení jednotlivých světel semaforu
            //Semafor - dole uprostřed
            g.DrawEllipse(black, 300, 410, d, d);            //red
            g.DrawEllipse(black, 300, 435, d, d);            //orange
            g.DrawEllipse(black, 300, 460, d, d);            //green
            //Semafor - dole vpravo
            g.DrawEllipse(black, 385, 410, d, d);            //red
            g.DrawEllipse(black, 385, 435, d, d);            //orange
            g.DrawEllipse(black, 385, 460, d, d);            //green
            //Semafor - nahoře uprostřed
            g.DrawEllipse(black, 300, 190, d, d);            //red
            g.DrawEllipse(black, 300, 165, d, d);            //orange
            g.DrawEllipse(black, 300, 140, d, d);            //green
            //Semafor - nahoře vlevo
            g.DrawEllipse(black, 215, 190, d, d);            //red
            g.DrawEllipse(black, 215, 165, d, d);            //orange
            g.DrawEllipse(black, 215, 140, d, d);            //green
            //Semafor - vlevo
            g.DrawEllipse(black, 190, 360, d, d);            //red
            g.DrawEllipse(black, 165, 360, d, d);            //orange
            g.DrawEllipse(black, 140, 360, d, d);            //green
            g.DrawEllipse(black, 190, 385, d, d);            //green - right
            //Semafor - vpravo
            g.DrawEllipse(black, 410, 240, d, d);            //red
            g.DrawEllipse(black, 435, 240, d, d);            //orange
            g.DrawEllipse(black, 460, 240, d, d);            //green
            g.DrawEllipse(black, 410, 215, d, d);            //green - right
            //Semafor - chodci - vlevo - nahoře
            g.DrawEllipse(black, 80, 240, d, d);             //red
            g.DrawEllipse(black, 80, 215, d, d);             //green
            //Semafor - chodci - vlevo - dole 
            g.DrawEllipse(black, 80, 360, d, d);             //red
            g.DrawEllipse(black, 80, 385, d, d);             //green
            //Semafor - chodci - vpravo - nahoře
            g.DrawEllipse(black, 520, 240, d, d);            //red
            g.DrawEllipse(black, 520, 215, d, d);            //green
            //Semafor - chodci - vpravo - dole
            g.DrawEllipse(black, 520, 360, d, d);            //red
            g.DrawEllipse(black, 520, 385, d, d);            //green
            //Semafor - chodci - nahoře - vlevo
            g.DrawEllipse(black, 240, 80, d, d);            //red
            g.DrawEllipse(black, 215, 80, d, d);            //green
            //Semafor - chodci - nahoře - vpravo
            g.DrawEllipse(black, 360, 80, d, d);             //red
            g.DrawEllipse(black, 385, 80, d, d);             //green
            //Semafor - chodci - dole - vlevo
            g.DrawEllipse(black, 240, 520, d, d);            //red
            g.DrawEllipse(black, 215, 520, d, d);            //green
            //Semafor - chodci - dole - vpravo
            g.DrawEllipse(black, 360, 520, d, d);            //red
            g.DrawEllipse(black, 385, 520, d, d);            //green

        }
        //Timer pro změnu stavu aktivních světel křižovatky
        private void Timer1_Tick(object sender, EventArgs e)
        {
            Graphics g = panel1.CreateGraphics();   //Zapnutí grafiky v Crossroads

            //Nulování - "vypnutí světla" v grafice
            g.FillEllipse(White, 300, 410, d, d);   //Semafor - dole uprostřed
            g.FillEllipse(White, 300, 435, d, d);
            g.FillEllipse(White, 300, 460, d, d);
            g.FillEllipse(White, 385, 410, d, d);   //Semafor - dole vpravo
            g.FillEllipse(White, 385, 435, d, d);
            g.FillEllipse(White, 385, 460, d, d);
            g.FillEllipse(White, 300, 190, d, d);   //Semafor - nahoře uprostřed
            g.FillEllipse(White, 300, 165, d, d);
            g.FillEllipse(White, 300, 140, d, d);
            g.FillEllipse(White, 215, 190, d, d);   //Semafor - nahoře vlevo
            g.FillEllipse(White, 215, 165, d, d);
            g.FillEllipse(White, 215, 140, d, d);
            g.FillEllipse(White, 190, 360, d, d);   //Semafor - vlevo
            g.FillEllipse(White, 165, 360, d, d);
            g.FillEllipse(White, 140, 360, d, d);
            g.FillEllipse(White, 190, 385, d, d);
            g.FillEllipse(White, 410, 240, d, d);   //Semafor - vpravo
            g.FillEllipse(White, 435, 240, d, d);
            g.FillEllipse(White, 460, 240, d, d);
            g.FillEllipse(White, 410, 215, d, d);
            g.FillEllipse(White, 80, 240, d, d);    //Semafor - chodci - vlevo nahoře
            g.FillEllipse(White, 80, 215, d, d);
            g.FillEllipse(White, 80, 360, d, d);    //Semafor - chodci - vlevo dole
            g.FillEllipse(White, 80, 385, d, d);
            g.FillEllipse(White, 520, 240, d, d);   //Semafor - chodci - vpravo nahoře
            g.FillEllipse(White, 520, 215, d, d);
            g.FillEllipse(White, 520, 360, d, d);   //Semafor - chodci - vpravo dole
            g.FillEllipse(White, 520, 385, d, d);
            g.FillEllipse(White, 240, 80, d, d);    //Semafor - chodci - nahoře vlevo
            g.FillEllipse(White, 215, 80, d, d);
            g.FillEllipse(White, 360, 80, d, d);    //Semafor - chodci - nahoře vpravo
            g.FillEllipse(White, 385, 80, d, d);
            g.FillEllipse(White, 240, 520, d, d);   //Semafor - chodci - dole vlevo         
            g.FillEllipse(White, 215, 520, d, d);
            g.FillEllipse(White, 360, 520, d, d);   //Semafor - chodci - dole vpravo
            g.FillEllipse(White, 385, 520, d, d);

            
            if (ModeDay == 0)    //0 = stisknuto tlačítko; 1 = tlačítko nestisknuto
            {
                StatusNight = 0; //nulovování
                if (StatusDay == 12) StatusDay = 1; //Zacyklení všech stavů křižovatky
                switch (StatusDay)
                {
                    case 7: //Stav 7 - shodný se stavem 1 - na všech červená
                    case 1: //Stav 1 - na všech červená

                        PortA = Status1A; //Status7A
                        PortB = Status1B; //Status7B

                        g.FillEllipse(Red, 300, 410, d, d);     //red - hlavní - auta
                        g.FillEllipse(Red, 385, 410, d, d);     //red - hlavní
                        g.FillEllipse(Red, 300, 190, d, d);     //red - hlavní
                        g.FillEllipse(Red, 215, 190, d, d);     //red - hlavní
                        g.FillEllipse(Red, 190, 360, d, d);     //red - vedlejší - auta
                        g.FillEllipse(Red, 410, 240, d, d);     //red - vedlejší - auta
                        g.FillEllipse(Red, 80, 240, d, d);      //red - vedlejší - chodci
                        g.FillEllipse(Red, 80, 360, d, d);      //red - vedlejší
                        g.FillEllipse(Red, 520, 240, d, d);     //red - vedlejší
                        g.FillEllipse(Red, 520, 360, d, d);     //red - vedlejší
                        g.FillEllipse(Red, 240, 80, d, d);      //red - hlavní - chodci
                        g.FillEllipse(Red, 360, 80, d, d);      //red - hlavní
                        g.FillEllipse(Red, 240, 520, d, d);     //red - hlavní
                        g.FillEllipse(Red, 360, 520, d, d);     //red - hlavní
                        break;

                    case 2: //Stav 2 - hlavní -  červená a oranžová; chodci - vedlejší - zelená; zbytek červená

                        PortA = Status2A;
                        PortB = Status2B;

                        g.FillEllipse(Red, 300, 410, d, d);     //red - hlavní - auta
                        g.FillEllipse(Red, 385, 410, d, d);     //red - hlavní
                        g.FillEllipse(Red, 300, 190, d, d);     //red - hlavní
                        g.FillEllipse(Red, 215, 190, d, d);     //red - hlavní
                        g.FillEllipse(Orange, 385, 435, d, d);  //orange - dole - kraj
                        g.FillEllipse(Orange, 215, 165, d, d);  //orange - nahoře - kraj
                        g.FillEllipse(Red, 190, 360, d, d);     //red - vedlejší - auta
                        g.FillEllipse(Red, 410, 240, d, d);     //red - vedlejší - auta
                        g.FillEllipse(Green, 80, 215, d, d);    //green - chodci - vedlejší
                        g.FillEllipse(Green, 80, 385, d, d);    //green - chodci - vedlejší
                        g.FillEllipse(Green, 520, 215, d, d);   //green - chodci - vedlejší
                        g.FillEllipse(Green, 520, 385, d, d);   //green - chodci - vedlejší
                        g.FillEllipse(Red, 240, 80, d, d);      //red - hlavní - chodci
                        g.FillEllipse(Red, 360, 80, d, d);      //red - hlavní
                        g.FillEllipse(Red, 240, 520, d, d);     //red - hlavní
                        g.FillEllipse(Red, 360, 520, d, d);     //red - hlavní
                        break;
                        
                    case 3: //Stav 3 - hlavní pravá - zelená; chodci - vedlejší - zelená; zbytek červená

                        PortA = Status3A;
                        PortB = Status3B;

                        g.FillEllipse(Red, 300, 410, d, d);     //red - hlavní - auta
                        g.FillEllipse(Red, 300, 190, d, d);     //red - hlavní
                        g.FillEllipse(Green, 385, 460, d, d);   //green - kraj - dole
                        g.FillEllipse(Green, 215, 140, d, d);   //green - kraj - nahoře
                        g.FillEllipse(Red, 190, 360, d, d);     //red - vedlejší - auta
                        g.FillEllipse(Red, 410, 240, d, d);     //red - vedlejší - auta
                        g.FillEllipse(Green, 80, 215, d, d);    //green - chodci - vedlejší
                        g.FillEllipse(Green, 80, 385, d, d);    //green - chodci - vedlejší
                        g.FillEllipse(Green, 520, 215, d, d);   //green - chodci - vedlejší
                        g.FillEllipse(Green, 520, 385, d, d);   //green - chodci - vedlejší
                        g.FillEllipse(Red, 240, 80, d, d);      //red - hlavní - chodci
                        g.FillEllipse(Red, 360, 80, d, d);      //red - hlavní
                        g.FillEllipse(Red, 240, 520, d, d);     //red - hlavní
                        g.FillEllipse(Red, 360, 520, d, d);     //red - hlavní
                        break;
                        
                    case 4: //Stav 4 - hlavní střed -  červená a oranžová; hlavní pravá - zelená; chodci - vedlejší - zelená; zbytek červená

                        PortA = Status4A;
                        PortB = Status4B;

                        g.FillEllipse(Red, 300, 410, d, d);     //red - hlavní - auta
                        g.FillEllipse(Red, 300, 190, d, d);     //red - hlavní
                        g.FillEllipse(Orange, 300, 435, d, d);  //orange  - dole - střed
                        g.FillEllipse(Orange, 300, 165, d, d);  //orange - nahoře - střed
                        g.FillEllipse(Green, 385, 460, d, d);   //green - kraj - dole
                        g.FillEllipse(Green, 215, 140, d, d);   //green - kraj - nahoře
                        g.FillEllipse(Red, 190, 360, d, d);     //red - vedlejší - auta
                        g.FillEllipse(Red, 410, 240, d, d);     //red - vedlejší - auta
                        g.FillEllipse(Green, 80, 215, d, d);    //green - chodci - vedlejší
                        g.FillEllipse(Green, 80, 385, d, d);    //green - chodci - vedlejší
                        g.FillEllipse(Green, 520, 215, d, d);   //green - chodci - vedlejší
                        g.FillEllipse(Green, 520, 385, d, d);   //green - chodci - vedlejší
                        g.FillEllipse(Red, 240, 80, d, d);      //red - hlavní - chodci
                        g.FillEllipse(Red, 360, 80, d, d);      //red - hlavní
                        g.FillEllipse(Red, 240, 520, d, d);     //red - hlavní
                        g.FillEllipse(Red, 360, 520, d, d);     //red - hlavní
                        break;

                    case 5: //Stav 5 - hlavní - zelená; chodci - vedlejší - zelená; zbytek červená

                        PortA = Status5A;
                        PortB = Status5B;

                        g.FillEllipse(Green, 300, 460, d, d);   //green - střed - dole
                        g.FillEllipse(Green, 385, 460, d, d);   //green - kraj - dole
                        g.FillEllipse(Green, 300, 140, d, d);   //green - střed - nahoře
                        g.FillEllipse(Green, 215, 140, d, d);   //green - kraj - nahoře
                        g.FillEllipse(Red, 190, 360, d, d);     //red - vedlejší - auta
                        g.FillEllipse(Red, 410, 240, d, d);     //red - vedlejší - auta
                        g.FillEllipse(Green, 80, 215, d, d);    //green - chodci - vedlejší
                        g.FillEllipse(Green, 80, 385, d, d);    //green - chodci - vedlejší
                        g.FillEllipse(Green, 520, 215, d, d);   //green - chodci - vedlejší
                        g.FillEllipse(Green, 520, 385, d, d);   //green - chodci - vedlejší
                        g.FillEllipse(Red, 240, 80, d, d);      //red - hlavní - chodci
                        g.FillEllipse(Red, 360, 80, d, d);      //red - hlavní
                        g.FillEllipse(Red, 240, 520, d, d);     //red - hlavní
                        g.FillEllipse(Red, 360, 520, d, d);     //red - hlavní
                        break;

                    case 6: //Stav 6 - hlavní - oranžová; chodci vedlejší - zelená; zbytek červená    

                        PortA = Status6A;
                        PortB = Status6B;

                        g.FillEllipse(Orange, 300, 435, d, d);  //orange 
                        g.FillEllipse(Orange, 385, 435, d, d);  //orange
                        g.FillEllipse(Orange, 300, 165, d, d);  //orange
                        g.FillEllipse(Orange, 215, 165, d, d);  //orange
                        g.FillEllipse(Red, 190, 360, d, d);     //red - vedlejší - auta
                        g.FillEllipse(Red, 410, 240, d, d);     //red - vedlejší - auta
                        g.FillEllipse(Green, 80, 215, d, d);    //green - chodci - vedlejší
                        g.FillEllipse(Green, 80, 385, d, d);    //green - chodci - vedlejší
                        g.FillEllipse(Green, 520, 215, d, d);   //green - chodci - vedlejší
                        g.FillEllipse(Green, 520, 385, d, d);   //green - chodci - vedlejší
                        g.FillEllipse(Red, 240, 80, d, d);      //red - hlavní - chodci
                        g.FillEllipse(Red, 360, 80, d, d);      //red - hlavní
                        g.FillEllipse(Red, 240, 520, d, d);     //red - hlavní
                        g.FillEllipse(Red, 360, 520, d, d);     //red - hlavní
                        break;

                    case 8: //Stav 8 Vedlejší - zelená right; vedlejší - červená; Chodci - hlavní - zelená; zbytek červená

                        PortA = Status8A;
                        PortB = Status8B;

                        g.FillEllipse(Red, 300, 410, d, d);     //red - hlavní - auta
                        g.FillEllipse(Red, 385, 410, d, d);     //red - hlavní
                        g.FillEllipse(Red, 300, 190, d, d);     //red - hlavní
                        g.FillEllipse(Red, 215, 190, d, d);     //red - hlavní
                        g.FillEllipse(Red, 190, 360, d, d);     //red - vedlejší - auta
                        g.FillEllipse(Green, 190, 385, d, d);   //green - right - vedlejší
                        g.FillEllipse(Red, 410, 240, d, d);     //red - vedlejší - auta
                        g.FillEllipse(Green, 410, 215, d, d);   //green - right - vedlejší
                        g.FillEllipse(Red, 80, 240, d, d);      //red - vedlejší - chodci
                        g.FillEllipse(Red, 80, 360, d, d);      //red - vedlejší
                        g.FillEllipse(Red, 520, 240, d, d);     //red - vedlejší
                        g.FillEllipse(Red, 520, 360, d, d);     //red - vedlejší
                        g.FillEllipse(Green, 215, 80, d, d);    //green - chodci - hlavní
                        g.FillEllipse(Green, 385, 80, d, d);    //green - chodci - hlavní
                        g.FillEllipse(Green, 215, 520, d, d);   //green - chodci - hlavní
                        g.FillEllipse(Green, 385, 520, d, d);   //green - chodci - hlavní
                        break;

                    case 9: //Stav 9 Vedlejší - zelená right; Vedlejší - červená a oranžová; Chodci - hlavní - zelená; zbytek červená

                        PortA = Status9A;
                        PortB = Status9B;

                        g.FillEllipse(Red, 300, 410, d, d);     //red - hlavní - auta
                        g.FillEllipse(Red, 385, 410, d, d);     //red - hlavní
                        g.FillEllipse(Red, 300, 190, d, d);     //red - hlavní
                        g.FillEllipse(Red, 215, 190, d, d);     //red - hlavní
                        g.FillEllipse(Red, 190, 360, d, d);     //red - vedlejší - auta
                        g.FillEllipse(Orange, 165, 360, d, d);  //orange - vedlejší
                        g.FillEllipse(Green, 190, 385, d, d);   //green - right - vedlejší
                        g.FillEllipse(Red, 410, 240, d, d);     //red - vedlejší - auta
                        g.FillEllipse(Orange, 435, 240, d, d);  //orange - vedlejší
                        g.FillEllipse(Green, 410, 215, d, d);   //green - right - vedlejší
                        g.FillEllipse(Red, 80, 240, d, d);      //red - vedlejší - chodci
                        g.FillEllipse(Red, 80, 360, d, d);      //red - vedlejší
                        g.FillEllipse(Red, 520, 240, d, d);     //red - vedlejší
                        g.FillEllipse(Red, 520, 360, d, d);     //red - vedlejší
                        g.FillEllipse(Green, 215, 80, d, d);    //green - chodci - hlavní
                        g.FillEllipse(Green, 385, 80, d, d);    //green - chodci - hlavní
                        g.FillEllipse(Green, 215, 520, d, d);   //green - chodci - hlavní
                        g.FillEllipse(Green, 385, 520, d, d);   //green - chodci - hlavní
                        break;

                    case 10: //Stav 10 Vedlejší zelená - right; vedlejší zelená; Chodci - hlavní - zelená; zbytek červená

                        PortA = Status10A;
                        PortB = Status10B;

                        g.FillEllipse(Red, 300, 410, d, d);     //red - hlavní - auta
                        g.FillEllipse(Red, 385, 410, d, d);     //red - hlavní
                        g.FillEllipse(Red, 300, 190, d, d);     //red - hlavní
                        g.FillEllipse(Red, 215, 190, d, d);     //red - hlavní
                        g.FillEllipse(Green, 140, 360, d, d);   //green
                        g.FillEllipse(Green, 190, 385, d, d);   //green - right - vedlejší
                        g.FillEllipse(Green, 460, 240, d, d);   //green
                        g.FillEllipse(Green, 410, 215, d, d);   //green - right - vedlejší
                        g.FillEllipse(Red, 80, 240, d, d);      //red - vedlejší - chodci
                        g.FillEllipse(Red, 80, 360, d, d);      //red - vedlejší
                        g.FillEllipse(Red, 520, 240, d, d);     //red - vedlejší
                        g.FillEllipse(Red, 520, 360, d, d);     //red - vedlejší
                        g.FillEllipse(Green, 215, 80, d, d);    //green - chodci - hlavní
                        g.FillEllipse(Green, 385, 80, d, d);    //green - chodci - hlavní
                        g.FillEllipse(Green, 215, 520, d, d);   //green - chodci - hlavní
                        g.FillEllipse(Green, 385, 520, d, d);   //green - chodci - hlavní
                        break;

                    case 11: //Stav 11 Vedlejší oranžová; chodci hlavní - zelená; zbytek červená

                        PortA = Status11A;
                        PortB = Status11B;

                        g.FillEllipse(Red, 300, 410, d, d);     //red - hlavní - auta
                        g.FillEllipse(Red, 385, 410, d, d);     //red - hlavní
                        g.FillEllipse(Red, 300, 190, d, d);     //red - hlavní
                        g.FillEllipse(Red, 215, 190, d, d);     //red - hlavní
                        g.FillEllipse(Orange, 165, 360, d, d);  //orange - vedlejší
                        g.FillEllipse(Orange, 435, 240, d, d);  //orange - vedlejší
                        g.FillEllipse(Red, 80, 240, d, d);      //red - vedlejší - chodci
                        g.FillEllipse(Red, 80, 360, d, d);      //red - vedlejší
                        g.FillEllipse(Red, 520, 240, d, d);     //red - vedlejší
                        g.FillEllipse(Red, 520, 360, d, d);     //red - vedlejší
                        g.FillEllipse(Green, 215, 80, d, d);    //green - chodci - hlavní
                        g.FillEllipse(Green, 385, 80, d, d);    //green - chodci - hlavní
                        g.FillEllipse(Green, 215, 520, d, d);   //green - chodci - hlavní
                        g.FillEllipse(Green, 385, 520, d, d);   //green - chodci - hlavní
                        break;

                }   //konec Switche

                StatusDay++;    //inkrementace stavu světel křižovatky

            }       //konec podmínky If

            if (ModeNight == 0) //0 = stisknuto tlačítko; 1 = tlačítko nestisknuto
            {
                StatusDay = 0;  //nulovování
                if (StatusNight == 2) StatusNight = 0;
                switch (StatusNight)
                {
                    case 0: //Stav 0 - nic nesvítí

                        PortA = StatusNight0A;
                        PortB = StatusNight0B;

                        g.FillEllipse(White, 300, 435, d, d);   //white - hlavní
                        g.FillEllipse(White, 385, 435, d, d);   //white - hlavní
                        g.FillEllipse(White, 300, 165, d, d);   //white - hlavní
                        g.FillEllipse(White, 215, 165, d, d);   //white - hlavní
                        g.FillEllipse(White, 165, 360, d, d);   //white - vedlejší
                        g.FillEllipse(White, 435, 240, d, d);   //white - vedlejší
                        break;
                    case 1: //Stav 1 - svtítí všude oranžová - chodci nesvítí ani červená, ani zelená

                        PortA = StatusNight1A;
                        PortB = StatusNight1B;

                        g.FillEllipse(Orange, 300, 435, d, d);  //orange - hlavní
                        g.FillEllipse(Orange, 385, 435, d, d);  //orange - hlavní
                        g.FillEllipse(Orange, 300, 165, d, d);  //orange - hlavní
                        g.FillEllipse(Orange, 215, 165, d, d);  //orange - hlavní
                        g.FillEllipse(Orange, 165, 360, d, d);  //orange - vedlejší
                        g.FillEllipse(Orange, 435, 240, d, d);  //orange - vedlejší
                        break;

                }   //konec Switche

                StatusNight++;

            }       //konec podmínky If

        /*
            // V komentáři, kvůli odzkoušení, grafiky v C#, nutno pro zkoušku s HW
            //Zapsání kombinací na porty
            K8055D.SetCurrentDevice(0);
            K8055D.OpenDevice(0);
            K8055D.WriteAllDigital(PortA);
            //K8055D.CloseDevice(0);
            K8055D.SetCurrentDevice(1);
            K8055D.OpenDevice(1);
            K8055D.WriteAllDigital(PortB);
            //K8055D.CloseDevice(1);
        */                

        }           //konec "přerušení" Timer1
        
        //Timer pro kontrolu tlačítek
        private void Timer2_Tick(object sender, EventArgs e)
        {
            K8055D.SetCurrentDevice(0);
            K8055D.OpenDevice(0);
            K8055D.ReadDigitalChannel(Mode);    //Načtení z Card 0 Piny pro vstup
            //K8055D.CloseDevice(0);            //není nutné zavírat HW, při přepojení,
            
            if (Mode == 0b1110)                 //nutnost stisku, právě 1 tlačítka
            {
                ModeDay = 0;
                ModeNight = 1;
            }
            if (Mode == 0b1101)                 //nutnost stisku, právě 1 tlačítka
            {
                ModeDay = 1;
                ModeNight = 0;
            }

        }           //konec "přerušení" Timer2

        //Ovládání dne/noci z prostředí grafiky C#
        private void Day_button_Click(object sender, EventArgs e) 
        {
            ModeDay = 0;
            ModeNight = 1;
        }

        private void Night_button_Click(object sender, EventArgs e)
        {
            ModeDay = 1;
            ModeNight = 0;
        }

    }

}
