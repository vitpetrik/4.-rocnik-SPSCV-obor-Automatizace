﻿namespace Uloha4_Krizovatka
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Timer1 = new System.Windows.Forms.Timer(this.components);
            this.Timer2 = new System.Windows.Forms.Timer(this.components);
            this.Day_button = new System.Windows.Forms.Button();
            this.Night_button = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Location = new System.Drawing.Point(2, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(969, 798);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Timer1
            // 
            this.Timer1.Interval = 2000;
            this.Timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // Timer2
            // 
            this.Timer2.Tick += new System.EventHandler(this.Timer2_Tick);
            // 
            // Day_button
            // 
            this.Day_button.Location = new System.Drawing.Point(994, 125);
            this.Day_button.Name = "Day_button";
            this.Day_button.Size = new System.Drawing.Size(135, 65);
            this.Day_button.TabIndex = 1;
            this.Day_button.Text = "Day";
            this.Day_button.UseVisualStyleBackColor = true;
            this.Day_button.Click += new System.EventHandler(this.Day_button_Click);
            // 
            // Night_button
            // 
            this.Night_button.Location = new System.Drawing.Point(994, 227);
            this.Night_button.Name = "Night_button";
            this.Night_button.Size = new System.Drawing.Size(135, 65);
            this.Night_button.TabIndex = 2;
            this.Night_button.Text = "Night";
            this.Night_button.UseVisualStyleBackColor = true;
            this.Night_button.Click += new System.EventHandler(this.Night_button_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1162, 810);
            this.Controls.Add(this.Night_button);
            this.Controls.Add(this.Day_button);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Timer Timer1;
        private System.Windows.Forms.Timer Timer2;
        private System.Windows.Forms.Button Day_button;
        private System.Windows.Forms.Button Night_button;
    }
}

